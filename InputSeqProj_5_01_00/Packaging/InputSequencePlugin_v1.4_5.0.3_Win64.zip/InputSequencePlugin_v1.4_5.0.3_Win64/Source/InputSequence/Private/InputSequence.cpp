// Copyright 2022 Pentangle Studio Licensed under the Apache License, Version 2.0 (the «License»);

#include "InputSequence.h"

#define LOCTEXT_NAMESPACE "FInputSequenceModule"

void FInputSequenceModule::StartupModule()
{
}

void FInputSequenceModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FInputSequenceModule, InputSequence)